from flask import Flask, request, redirect, render_template_string
import sqlite3
from datetime import datetime

app = Flask(__name__)

def koneksi():
    conn = sqlite3.connect("barang.db")
    conn.row_factory = sqlite3.Row
    return conn

def buat_tabel():
    conn = koneksi()

    conn.execute("""
        CREATE TABLE IF NOT EXISTS barang (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            nama TEXT NOT NULL,
            harga INTEGER NOT NULL,
            stok INTEGER NOT NULL
        )
    """)

    conn.execute("""
        CREATE TABLE IF NOT EXISTS transaksi (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            nama_barang TEXT NOT NULL,
            jenis TEXT NOT NULL,
            jumlah INTEGER NOT NULL,
            total INTEGER NOT NULL,
            tanggal TEXT NOT NULL,
            keterangan TEXT
        )
    """)

    conn.commit()
    conn.close()

# Dibuat di awal supaya database juga siap saat dijalankan Gunicorn/hosting.
buat_tabel()

halaman = """
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Sistem Penjualan Barang</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            background: #f1f5f9;
            margin: 0;
            color: #1e293b;
        }
        header {
            background: #1d4ed8;
            color: white;
            padding: 22px;
            text-align: center;
        }
        main {
            max-width: 1000px;
            margin: 25px auto;
            padding: 15px;
        }
        .ringkasan {
            display: flex;
            gap: 15px;
            flex-wrap: wrap;
        }
        .kartu {
            background: white;
            padding: 20px;
            border-radius: 10px;
            flex: 1;
            min-width: 150px;
            box-shadow: 0 2px 8px #0001;
        }
        .form, .tabel {
            background: white;
            padding: 20px;
            margin-top: 20px;
            border-radius: 10px;
            overflow-x: auto;
        }
        input, select, button {
            padding: 10px;
            margin: 5px 0;
            box-sizing: border-box;
        }
        input, select {
            border: 1px solid #cbd5e1;
            border-radius: 5px;
            width: 100%;
        }
        button {
            background: #1d4ed8;
            color: white;
            border: none;
            border-radius: 5px;
            cursor: pointer;
        }
        table {
            width: 100%;
            border-collapse: collapse;
            min-width: 550px;
        }
        th, td {
            padding: 12px;
            border-bottom: 1px solid #e2e8f0;
            text-align: left;
        }
        th {
            background: #eff6ff;
        }
        .pesan {
            background: #dcfce7;
            padding: 12px;
            border-radius: 5px;
        }
    </style>
</head>
<body>
<header>
    <h1>Sistem Penjualan Barang</h1>
    <p>Aplikasi pengelolaan stok dan transaksi barang</p>
</header>

<main>
    {% if pesan %}
        <p class="pesan">{{ pesan }}</p>
    {% endif %}

    <div class="ringkasan">
        <div class="kartu">
            <h3>Total Jenis Barang</h3>
            <h2>{{ jumlah_barang }}</h2>
        </div>
        <div class="kartu">
            <h3>Total Stok</h3>
            <h2>{{ total_stok }}</h2>
        </div>
        <div class="kartu">
            <h3>Total Penjualan</h3>
            <h2>Rp{{ "{:,.0f}".format(total_penjualan) }}</h2>
        </div>
    </div>

    <section class="form">
        <h2>Tambah Barang</h2>
        <form action="/tambah" method="POST">
            <input name="nama" placeholder="Nama barang" required>
            <input name="harga" type="number" min="0"
                   placeholder="Harga barang" required>
            <input name="stok" type="number" min="0"
                   placeholder="Jumlah stok" required>
            <button type="submit">Simpan Barang</button>
        </form>
    </section>

    <section class="form">
        <h2>Transaksi Barang</h2>
        <form action="/transaksi" method="POST">
            <label>Pilih Barang</label>
            <select name="barang_id" required>
                {% for b in barang %}
                    <option value="{{ b.id }}">
                        {{ b.nama }} - Stok: {{ b.stok }}
                        - Rp{{ "{:,.0f}".format(b.harga) }}
                    </option>
                {% endfor %}
            </select>

            <label>Jenis Transaksi</label>
            <select name="jenis">
                <option value="Penjualan">Penjualan</option>
                <option value="Pengeluaran">Pengeluaran Barang</option>
            </select>

            <input name="jumlah" type="number" min="1"
                   placeholder="Jumlah barang" required>

            <input name="keterangan"
                   placeholder="Keterangan / tujuan pengeluaran">

            <button type="submit">Simpan Transaksi</button>
        </form>
    </section>

    <section class="tabel">
        <h2>Daftar Barang</h2>
        <table>
            <tr>
                <th>Nama Barang</th>
                <th>Harga</th>
                <th>Stok</th>
            </tr>
            {% for b in barang %}
            <tr>
                <td>{{ b.nama }}</td>
                <td>Rp{{ "{:,.0f}".format(b.harga) }}</td>
                <td>{{ b.stok }}</td>
            </tr>
            {% else %}
            <tr><td colspan="3">Belum ada barang.</td></tr>
            {% endfor %}
        </table>
    </section>

    <section class="tabel">
        <h2>Riwayat Transaksi</h2>
        <table>
            <tr>
                <th>Tanggal</th>
                <th>Barang</th>
                <th>Jenis</th>
                <th>Jumlah</th>
                <th>Total</th>
                <th>Keterangan</th>
            </tr>
            {% for t in transaksi %}
            <tr>
                <td>{{ t.tanggal }}</td>
                <td>{{ t.nama_barang }}</td>
                <td>{{ t.jenis }}</td>
                <td>{{ t.jumlah }}</td>
                <td>Rp{{ "{:,.0f}".format(t.total) }}</td>
                <td>{{ t.keterangan or "-" }}</td>
            </tr>
            {% else %}
            <tr><td colspan="6">Belum ada transaksi.</td></tr>
            {% endfor %}
        </table>
    </section>
</main>
</body>
</html>
"""

@app.route("/")
def index():
    conn = koneksi()

    barang = conn.execute(
        "SELECT * FROM barang ORDER BY nama"
    ).fetchall()

    transaksi = conn.execute(
        "SELECT * FROM transaksi ORDER BY id DESC"
    ).fetchall()

    jumlah_barang = conn.execute(
        "SELECT COUNT(*) FROM barang"
    ).fetchone()[0]

    total_stok = conn.execute(
        "SELECT COALESCE(SUM(stok), 0) FROM barang"
    ).fetchone()[0]

    total_penjualan = conn.execute(
        "SELECT COALESCE(SUM(total), 0) FROM transaksi "
        "WHERE jenis = 'Penjualan'"
    ).fetchone()[0]

    conn.close()

    pesan = request.args.get("pesan", "")

    return render_template_string(
        halaman,
        barang=barang,
        transaksi=transaksi,
        jumlah_barang=jumlah_barang,
        total_stok=total_stok,
        total_penjualan=total_penjualan,
        pesan=pesan
    )

@app.route("/tambah", methods=["POST"])
def tambah():
    nama = request.form["nama"].strip()
    harga = int(request.form["harga"])
    stok = int(request.form["stok"])

    if not nama or harga < 0 or stok < 0:
        return redirect("/?pesan=Data+barang+tidak+valid")

    conn = koneksi()
    conn.execute(
        "INSERT INTO barang (nama, harga, stok) VALUES (?, ?, ?)",
        (nama, harga, stok)
    )
    conn.commit()
    conn.close()

    return redirect("/?pesan=Barang+berhasil+ditambahkan")

@app.route("/transaksi", methods=["POST"])
def transaksi_barang():
    barang_id = int(request.form["barang_id"])
    jenis = request.form["jenis"]
    jumlah = int(request.form["jumlah"])
    keterangan = request.form.get("keterangan", "").strip()

    if jumlah < 1 or jenis not in ["Penjualan", "Pengeluaran"]:
        return redirect("/?pesan=Transaksi+tidak+valid")

    conn = koneksi()

    barang = conn.execute(
        "SELECT * FROM barang WHERE id = ?", (barang_id,)
    ).fetchone()

    if barang is None:
        conn.close()
        return redirect("/?pesan=Barang+tidak+ditemukan")

    if barang["stok"] < jumlah:
        conn.close()
        return redirect("/?pesan=Stok+barang+tidak+cukup")

    total = barang["harga"] * jumlah

    conn.execute(
        "UPDATE barang SET stok = stok - ? WHERE id = ?",
        (jumlah, barang_id)
    )

    conn.execute("""
        INSERT INTO transaksi
        (nama_barang, jenis, jumlah, total, tanggal, keterangan)
        VALUES (?, ?, ?, ?, ?, ?)
    """, (
        barang["nama"],
        jenis,
        jumlah,
        total,
        datetime.now().strftime("%d-%m-%Y %H:%M"),
        keterangan
    ))

    conn.commit()
    conn.close()

    return redirect("/?pesan=Transaksi+berhasil+disimpan")

if __name__ == "__main__":
    app.run(debug=True)
