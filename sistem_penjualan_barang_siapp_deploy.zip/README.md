# Sistem Penjualan Barang

Aplikasi web sederhana menggunakan Python Flask untuk:
- Mengelola barang dan stok
- Mencatat penjualan
- Mencatat pengeluaran barang
- Melihat riwayat transaksi

## Menjalankan di komputer

```bash
pip install -r requirements.txt
python app.py
```

Buka http://127.0.0.1:5000

## Deploy ke Render

Build Command:
```bash
pip install -r requirements.txt
```

Start Command:
```bash
gunicorn app:app
```
